import SwiftUI
import Combine

/// Compact status row shown on the main dashboard while the app is licensed.
struct LicenseCounterView: View {
    @ObservedObject private var license = LicenseManager.shared
    @State private var currentTime = Date()

    private let refreshTimer = Timer.publish(every: 60, on: .main, in: .common).autoconnect()

    var body: some View {
        if let expiresAt = license.expiresAt {
            HStack(spacing: 12) {
                Image(systemName: "timer")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: 3) {
                    Text("Licença ativa")
                        .font(.subheadline.weight(.semibold))
                    Text(remainingTime(until: expiresAt))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if license.isRefreshing {
                    ProgressView()
                        .controlSize(.small)
                } else {
                    Text("Renova em")
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.tertiary)
                }
            }
            .onAppear {
                Task { await license.refreshValidation() }
            }
            .onReceive(refreshTimer) { date in
                currentTime = date
                license.enforceLocalExpiration(now: date)
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Licença ativa. \(remainingTime(until: expiresAt))")
        }
    }

    private func remainingTime(until expiresAt: Date) -> String {
        let remaining = max(0, Int(expiresAt.timeIntervalSince(currentTime)))
        let days = remaining / 86_400
        let hours = (remaining % 86_400) / 3_600
        return "\(days) dias e \(hours) horas restantes"
    }
}
