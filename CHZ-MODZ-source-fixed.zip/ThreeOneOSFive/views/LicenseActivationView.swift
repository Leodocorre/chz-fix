import SwiftUI

/// Full-screen gate shown when no valid license is present.
/// Blocks all interaction with the rest of the app until activation succeeds.
struct LicenseActivationView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject private var license = LicenseManager.shared

    @State private var keyInput = ""
    @State private var isBusy = false
    @State private var errorMessage: String?
    @State private var shakeTrigger = 0
    @FocusState private var fieldFocused: Bool

    var body: some View {
        ZStack {
            AppTheme.pageBackground.ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer(minLength: 24)

                header

                Spacer().frame(height: 36)

                formCard

                Spacer(minLength: 24)

                footer
                    .padding(.bottom, 28)
            }
            .padding(.horizontal, 24)
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                fieldFocused = true
            }
        }
    }

    // MARK: - Sections

    private var header: some View {
        VStack(spacing: 14) {
            
            Text("CHZ MODZ")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.primary)

            Text(language.text("license.title"))
                .font(.title3.weight(.semibold))
                .multilineTextAlignment(.center)

            Text(language.text("license.subtitle"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 8)
        }
    }

    private var formCard: some View {
        VStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text(language.text("license.key_label"))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)

                TextField(language.text("license.key_placeholder"), text: $keyInput)
                    .font(.system(.body, design: .monospaced))
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .keyboardType(.asciiCapable)
                    .submitLabel(.go)
                    .focused($fieldFocused)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 13)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color(uiColor: .secondarySystemFill))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .strokeBorder(
                                errorMessage != nil ? Color.red.opacity(0.7) : Color.clear,
                                lineWidth: 1.5
                            )
                    )
                    .modifier(ShakeEffect(shakes: shakeTrigger))
                    .onSubmit { activate() }
                    .onChange(of: keyInput) { _ in
                        if errorMessage != nil { errorMessage = nil }
                    }
            }

            if let errorMessage {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.caption)
                    Text(errorMessage)
                        .font(.footnote)
                }
                .foregroundStyle(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }

            Button(action: activate) {
                HStack(spacing: 8) {
                    if isBusy {
                        ProgressView()
                            .tint(.white)
                    } else {
                        Image(systemName: "lock.open.fill")
                            .font(.system(size: 15, weight: .semibold))
                    }
                    Text(language.text("license.activate"))
                        .font(.body.weight(.semibold))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .foregroundStyle(.white)
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(canActivate ? AppTheme.accent : Color.gray.opacity(0.45))
                )
            }
            .buttonStyle(.plain)
            .disabled(!canActivate || isBusy)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color(uiColor: .secondarySystemBackground))
        )
        .animation(.easeOut(duration: 0.2), value: errorMessage)
    }

    private var footer: some View {
        VStack(spacing: 6) {
            Text(language.text("license.footer"))
                .font(.caption)
                .foregroundStyle(.tertiary)
                .multilineTextAlignment(.center)

            if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
                Text(language.text("common.version", version))
                    .font(.caption2)
                    .foregroundStyle(.quaternary)
            }
        }
    }

    // MARK: - Logic

    private var canActivate: Bool {
        let trimmed = keyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.count >= 10
    }

    private func activate() {
        guard canActivate, !isBusy else { return }
        isBusy = true
        errorMessage = nil
        fieldFocused = false

        Task {
            do {
                try await license.activate(rawKey: keyInput)
                // Success: parent observes isLicensed and dismisses this view
            } catch let error as LicenseManager.ActivateError {
                errorMessage = error.localizedDescription
                shakeTrigger += 1
                fieldFocused = true
            } catch {
                errorMessage = error.localizedDescription
                shakeTrigger += 1
                fieldFocused = true
            }
            isBusy = false
        }
    }
}

// Simple horizontal shake for invalid key feedback
private struct ShakeEffect: GeometryEffect {
    var shakes: Int
    var animatableData: CGFloat {
        get { CGFloat(shakes) }
        set { shakes = Int(newValue) }
    }

    func effectValue(size: CGSize) -> ProjectionTransform {
        let offset = sin(animatableData * .pi * 2) * 8
        return ProjectionTransform(CGAffineTransform(translationX: offset, y: 0))
    }
}

#if DEBUG
struct LicenseActivationView_Previews: PreviewProvider {
    static var previews: some View {
        LicenseActivationView()
            .environment(\.appLanguage, .english)
    }
}
#endif
