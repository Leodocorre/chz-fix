# CHZ MODZ — Source (base 3105 + license gate)

## Alterações incluídas

- Sistema de **licença** (tela de ativação bloqueia o app sem key válida)
- Nome do app: **CHZ MODZ**
- Ícone customizado (logo N!X)
- API de licenças em `license-api/` (gerar / apagar / lote / validar)
- Script `generate_license.py` para keys offline
- Template `codemagic.yaml`

## Compilar no Codemagic

1. Suba este repositório no GitHub/GitLab
2. Conecte no [Codemagic](https://codemagic.io)
3. Use o workflow `ios-release` do `codemagic.yaml`
4. Configure **Enterprise certificate** + provisioning profile para  
   `com.apple.mobile.MobileHouseArrest`
5. **Não altere o Bundle ID** — o app depende dele para MHA

## Secret da licença

Antes de distribuir, altere o mesmo valor em **dois lugares**:

1. `ThreeOneOSFive/helpers/LicenseManager.swift` → `secret`
2. `license-api/app.py` / env `LICENSE_SECRET`
3. `generate_license.py` → `SECRET`

## Keys de teste (secret padrão)

```
python3 generate_license.py 5
```

## API de keys

Veja `license-api/README.md`. Painel: abra `license-api/admin.html`.
